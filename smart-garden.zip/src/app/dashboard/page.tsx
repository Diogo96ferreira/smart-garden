'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Check, AlarmClock, BadgeHelp } from 'lucide-react';
import { motion } from 'framer-motion';
import { LeafLoader } from '@/components/ui/Spinner';
import { supabase } from '@/lib/supabaseClient';

export default function DashboardPage() {
  const [doneTasks, setDoneTasks] = useState<number[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // 🔹 1️⃣ Fetch tasks from Supabase
  useEffect(() => {
    async function fetchTasks() {
      try {
        const { data, error } = await supabase
          .from('tasks')
          .select('*')
          .order('created_at', { ascending: true });

        if (error) throw error;
        setTasks(data || []);
      } catch (err) {
        console.error('Erro ao buscar tasks:', err);
      } finally {
        setLoading(false);
      }
    }

    fetchTasks();
  }, []);

  // 🔹 2️⃣ Load doneTasks from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('doneTasks');
    if (stored) {
      try {
        setDoneTasks(JSON.parse(stored));
      } catch {
        setDoneTasks([]);
      }
    }
  }, []);

  // 🔹 3️⃣ Save doneTasks to localStorage
  useEffect(() => {
    localStorage.setItem('doneTasks', JSON.stringify(doneTasks));
  }, [doneTasks]);

  // 🔹 4️⃣ Handle toggle
  const handleDone = (id: number) => {
    setDoneTasks((prev) =>
      prev.includes(id) ? prev.filter((t) => t !== id) : [...prev, id]
    );
  };

  // ⚠️ Condiciona apenas o conteúdo, não o hook
  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center ">
        <LeafLoader />
      </main>
    );
  }

  // ✅ Agora podes calcular progress em segurança
  const progress = Math.round((doneTasks.length / tasks.length) * 100);

  return (
    <main className="min-h-screen px-6 py-8 pb-28">
      <header className="mb-6 text-center">
        <p className="text-green-900 text-lg font-medium">Hello Diogo! 👋</p>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-green-800">
          Here’s what your garden needs this week 🌱
        </h1>
      </header>

      {/* 🌤️ Garden Overview */}
      <section className="bg-white/80 rounded-2xl shadow-md p-5 mb-6 text-green-900">
        <div className="flex justify-between items-center mb-3">
          <div>
            <p className="text-sm font-medium">🌤️ Garden status:</p>
            <h3 className="text-lg font-bold">
              {progress === 100
                ? 'Perfectly cared for! 🌼'
                : 'Healthy & hydrated'}
            </h3>
          </div>
          <div className="text-right text-sm text-gray-600">
            <p>
              Next rain: <span className="font-medium text-green-700">Fri</span>
            </p>
            <p>
              Tasks done:{' '}
              <span className="font-medium">
                {doneTasks.length}/{tasks.length}
              </span>
            </p>
          </div>
        </div>

        {/* 🌿 Progress Bar inside the card */}
        <div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs font-medium text-green-800">
              Weekly Progress
            </span>
            <span className="text-xs font-semibold text-green-700">
              {progress}%
            </span>
          </div>

          <div className="w-full h-3 bg-[#E4F6E4] rounded-full overflow-hidden shadow-inner">
            <motion.div
              className="h-full rounded-full bg-[#2E7D32]"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>
      </section>

      {/* 🪴 Task List */}
      <section className="space-y-5 max-w-2xl mx-auto">
        {tasks.map((task, index) => {
          const isDone = doneTasks.includes(task.id);
          return (
            <motion.div
              key={task.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`rounded-2xl p-5 shadow-md bg-white/80 transition-all duration-300 ${
                isDone ? 'opacity-70 border border-green-300' : ''
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 flex-shrink-0 overflow-hidden rounded-lg border border-gray-100">
                  <Image
                    src={task.image || '/alface.jpg'}
                    alt={task.title}
                    width={64}
                    height={64}
                    className="object-cover w-full h-full"
                  />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-lg text-green-800">
                    {task.title}
                  </h4>
                  <p className="text-sm text-gray-600">
                    {task.description || '—'}
                  </p>
                </div>
              </div>

              <div className="flex justify-center sm:justify-start gap-2 mt-4">
                <Button
                  onClick={() => handleDone(task.id)}
                  className={`rounded-full px-4 py-1.5 flex items-center gap-1 text-sm ${
                    isDone
                      ? 'bg-green-200 text-green-700'
                      : 'bg-green-500 text-white hover:bg-green-600'
                  }`}
                >
                  <Check className="w-4 h-4" /> {isDone ? 'Done!' : 'Done'}
                </Button>

                <Button
                  variant="outline"
                  className="rounded-full border bg-yellow-100 text-yellow-800 hover:bg-yellow-200 px-4 py-1.5 text-sm flex items-center gap-1"
                >
                  <AlarmClock className="w-4 h-4" /> Postpone
                </Button>

                <Button
                  variant="outline"
                  className="rounded-full bg-red-400 hover:bg-red-500 text-white px-4 py-1.5 text-sm flex items-center gap-1"
                >
                  <BadgeHelp className="w-4 h-4" /> How
                </Button>
              </div>
            </motion.div>
          );
        })}
      </section>
    </main>
  );
}
