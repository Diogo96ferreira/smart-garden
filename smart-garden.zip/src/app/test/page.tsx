"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Camera, User } from "lucide-react";
import {
  Avatar,
  AvatarImage,
} from "@/components/ui/avatar"
import TypingEffect from "@/components/ui/TypingEffect";
import { AvatarFallback } from "@radix-ui/react-avatar";
export default function AnalyzePage() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [result, setResult] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [question, setQuestion] = useState("");
  const [chat, setChat] = useState<{ role: string; text: string }[]>([]);
  const [userName, setUserName] = useState<string | null>(null);


  // === FOTO ===
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0] || null;
    setFile(selected);
    setResult("");
    if (selected) {
      const reader = new FileReader();
      reader.onload = (ev) => setPreview(ev.target?.result as string);
      reader.readAsDataURL(selected);
    } else setPreview(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setResult(null);

    if (!file) {
      setError("Por favor, seleciona uma imagem.");
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/analyze-image", { method: "POST", body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erro no servidor");

      const firstText = data.description || data.result?.description || ""; 
      setResult(firstText); 
      setChat([{ role: "adelia", text: firstText }]);
    } catch (err: any) {
      setError(err.message || "Erro desconhecido");
    } finally {
      setLoading(false);
    }
  };

  // 2) FOLLOW-UP -> /api/chat
  const handleFollowUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    const q = question;
    setChat(prev => [...prev, { role: "user", text: q }]);
    setQuestion("");

    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ context: result, question: q }), // usa o texto inicial como contexto
    });

    const data = await res.json();
    if (!res.ok) {
      setChat(prev => [...prev, { role: "adelia", text: "Atão, houve aqui um tropeção no fio… tenta outra vez, meu rico menino." }]);
      return;
    }
    setChat(prev => [...prev, { role: "adelia", text: data.reply }]);
  };

  useEffect(() => {
    const storedName = localStorage.getItem("userName");
    if (storedName) {
      setUserName(storedName);
    }
  }, []);
  const userInitial = userName ? userName.charAt(0).toUpperCase() : <User className="size-4" />;

  return (
    <div className="min-h-screen px-4 pb-16">
      <div className="max-w-lg mx-auto py-12 space-y-2">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-green-800 text-center">
          Pergunta à Tia Adélia
        </h1>
        <p className="text-center text-gray-600">
          Manda uma foto e depois conversa com ela 🌿
        </p>
      </div>

      {/* UPLOAD */}
      <form onSubmit={handleSubmit} className="space-y-6 text-center">
        <label
          htmlFor="file-upload"
          className="w-full flex flex-col items-center justify-center border-2 border-dashed border-green-300 bg-green-50 rounded-xl py-8 cursor-pointer hover:bg-green-100 transition relative"
        >
          {!preview ? (
            <>
              <Camera className="h-10 w-10 text-green-600 mb-3" />
              <p className="text-sm font-medium text-gray-700">
                Toca para selecionar ou tirar uma foto
              </p>
              <p className="text-xs text-gray-500 mt-1">
                (frutas, legumes, folhas, plantas...)
              </p>
            </>
          ) : (
            <div className="relative w-full max-w-[220px] aspect-square rounded-lg overflow-hidden border border-green-200 shadow-sm">
              <Image
                src={preview}
                alt="Pré-visualização"
                fill
                className="object-cover"
              />
            </div>
          )}
          <input
            id="file-upload"
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />
        </label>

        {preview && (
          <Button
            variant="outline"
            onClick={() => {
              setFile(null);
              setPreview(null);
              setResult("");
              setChat([]);
            }}
            className="text-sm text-gray-600 border-gray-300"
          >
            Remover imagem
          </Button>
        )}

        <Button
          type="submit"
          disabled={loading}
          className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition"
        >
          {loading ? "A analisar..." : "Enviar para a Tia Adélia"}
        </Button>
      </form>

      {/* ERROS */}
      {error && (
        <p className="text-red-600 mt-4 bg-red-100 p-3 rounded-md text-sm">
          ⚠️ {error}
        </p>
      )}

      {/* CHAT */}
      {chat.length > 0 && (
        <div>
          <div className="mt-6 p-4 bg-green-50 rounded-lg border border-green-200 text-left space-y-3">
            {chat.map((msg, i) => (
              <div key={i}>
                {msg.role === "adelia" ? (
                  <div className="text-green-800 flex items-start gap-2">
                    <Avatar>
                      <AvatarImage src="/avatar-adelia.jpg" alt="Ti Adélia Avatar" />
                    </Avatar>
                    <TypingEffect text={msg.text} />
                  </div>
                ) : (
                  <div className="text-green-800 flex items-start gap-2">
                    {/* Avatar do utilizador */}
                    {userName ? (
                      <Avatar>
                        <AvatarImage src={undefined} alt={userName} />
                        <AvatarFallback>{userInitial}</AvatarFallback>
                      </Avatar>
                    ) : (
                      <Avatar>
                        <AvatarFallback>{userInitial}</AvatarFallback>
                      </Avatar>
                    )}
                    <TypingEffect text={msg.text} />
                  </div>
                )}
              </div>
            ))}

          </div>
          <form onSubmit={handleFollowUp} className="flex items-center gap-2 mt-4">
            <input
              type="text"
              placeholder="Pergunta algo à Tia Adélia..."
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              className="flex-1 border border-green-300 rounded-lg p-2 text-sm"
            />
            <button
              type="submit"
              className="bg-green-600 hover:bg-green-700 text-white rounded-lg px-4 py-2 text-sm"
            >
              Perguntar
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
