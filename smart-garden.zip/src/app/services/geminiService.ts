import { GoogleGenAI, Type } from "@google/genai";
import type { ClassificationResult } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

const fileToGenerativePart = async (file: File) => {
    const base64EncodedDataPromise = new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(file);
    });
    return {
        inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
    };
};

export const classifyImage = async (imageFile: File): Promise<ClassificationResult> => {
    try {
        const imagePart = await fileToGenerativePart(imageFile);

        const prompt = `
Assume a persona da **Tia Adélia**, uma senhora portuguesa de campo, simpática e experiente em hortas e pomares.
A Tia Adélia fala de forma natural, calorosa e acessível, misturando sabedoria popular e conhecimento técnico de jardinagem.

Analisa a imagem que te envio e diz-me, no tom da Tia Adélia:
1️⃣ Que fruta ou vegetal é (se conseguires reconhecer).
2️⃣ Se parece saudável, maduro, verde ou passado.
3️⃣ Que sinais vês — cor, textura, folhas, ou presença de doenças, pragas ou falta de água.
4️⃣ Dá também um pequeno conselho de cuidado ou colheita, no teu estilo pessoal.

💡 **Exemplo de resposta esperada (em texto corrido):**
"Olha, meu querido, isto parece-me um tomate bem madurinho! Está com uma cor bonita e uniforme, sem manchas. 
Vê-se que apanhou sol e está pronto para a salada. Só tem cuidado com o excesso de rega, que às vezes estraga o sabor."

Responde sempre como a Tia Adélia, em tom afetuoso, natural e com um toque de sabedoria popular. 
Não uses linguagem técnica em excesso nem devolvas JSON — apenas texto corrido.
`;


        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, { text: prompt }] },
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        type: { type: Type.STRING },
                        species: { type: Type.STRING },
                        description: { type: Type.STRING },
                        isFruitOrVeg: { type: Type.BOOLEAN },
                        ripeness: { type: Type.STRING },
                        confidence: { type: Type.NUMBER },
                    },
                    required: ["type", "species", "description", "isFruitOrVeg", "ripeness", "confidence"],
                }
            }
        });

        const text = response.text.trim();
        if (!text) {
            throw new Error("API returned an empty response.");
        }

        const result = JSON.parse(text);
        return result as ClassificationResult;

    } catch (error) {
        console.error("Error classifying image:", error);
        throw new Error("Failed to communicate with the AI. Please check your API key and try again.");
    }
};