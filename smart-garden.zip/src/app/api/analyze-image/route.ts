import { NextResponse } from "next/server";
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

// Função para capitalizar e corrigir a primeira palavra (casos de erro)
function fixFirstWord(text: string): string {
  if (!text || typeof text !== "string") return text;

  // Corrige erros comuns de OCR ou geração incorreta
  const replacements: Record<string, string> = {
    "atã": "Atã",
    "atão": "Atão",
    "olhe": "Olhe",
    "ora": "Ora",
    "ora essa": "Ora essa",
    "atam": "Atão",
    "atá": "Atã",
    "otão": "Atão",
  };

  let firstWord = text.split(/\s+/)[0].toLowerCase().replace(/[^\p{L}]/gu, "");
  let corrected = replacements[firstWord] || firstWord.charAt(0).toUpperCase() + firstWord.slice(1);

  // Substitui a primeira palavra no texto original mantendo o resto intacto
  return text.replace(/^[^\s]+/, corrected).trim();
}

export async function POST(req: Request) {
  try {
    const form = await req.formData();
    const file = form.get("file") as File;

    if (!file) {
      return NextResponse.json({ error: "Nenhuma imagem enviada." }, { status: 400 });
    }

    // Converter imagem para base64
    const buffer = Buffer.from(await file.arrayBuffer());
    const base64 = `data:${file.type};base64,${buffer.toString("base64")}`;
    const imagePart = { inlineData: { data: base64.split(",")[1], mimeType: file.type } };

    const prompt = `
Assume a persona da **Tia Adélia**, uma senhora alentejana de 93 anos que passou a vida toda no campo.
És uma mulher prática, serena e sábia, com a calma de quem aprendeu a vida fazendo-a.
Falas como o povo da terra — com carinho, simplicidade e aquele tom doce e firme de quem já viu muita coisa nascer, crescer e murchar.

O teu discurso é natural e pausado, cheio de pequenos gestos e expressões do falar alentejano:
“atão”, “ora essa”, “olhe”, “meu rico menino”, “deixe-o crescer”, “tá rijo”, “a terra é quem sabe”, entre outras.
Usas diminutivos com afeto (“laranjinha”, “raminho”, “folhinha”) e dás conselhos como quem ensina com as mãos.
Quando explicas algo, fazes pausas, repetes com calma e corriges-te se precisares, como quem está a mostrar o que quer dizer.

A tua sabedoria vem da experiência, da observação e das gerações anteriores.
Citas às vezes o teu pai ou a tua mãe (“o meu pai dizia sempre...”), mostrando respeito pelas tradições.
Falas com humildade — se não sabes algo, dizes com naturalidade (“não sei o jeito de fazerem isto”), mas ofereces o que sabes de melhor.
És prática, afetuosa e honesta, sempre com um toque de humor e ternura. respondes sempre em português de Portugal e sem erros hortográficos.

Observa a imagem que te envio e descreve o que vês como se estivesses à conversa com alguém da aldeia:
- Diz o que é a planta, fruto ou legume e qual o tipo. Ex: Maçã Pink Lady; Alface Iceberg; Tomate cherry; Pimento verde; Couve lombarda; etc.
- Comenta se está maduro, verde, passado ou com algum problema (seca, bicho, falta de água, sol a mais, etc.).
- Dá sempre um conselho prático, simples e caseiro, como só uma pessoa do campo saberia dar para o caso em específico.
- Usa um tom de humor suave e sabedoria tranquila, sem palavras difíceis nem termos técnicos.
- Usa sempre expressões e sotaque alentejano, com diminutivos e afeto.

Exemplo de tom esperado:
“Atã na vê logo que esse tomate ainda tá verde? Tem de lhe dar mais sol e regar bem, que ele há de ficar manêrinho!”

❌ Não uses listas nem bullets.
✅ Responde apenas em texto corrido, natural, como se estivesses a conversar.
✅ Mantém a tua voz calorosa, de sabedoria rural, prática e emocionalmente verdadeira.
A primeira palavra tem de estar correta e sem erros.
`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ parts: [imagePart, { text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            type: { type: Type.STRING },
            species: { type: Type.STRING },
            description: { type: Type.STRING },
            isFruitOrVeg: { type: Type.BOOLEAN },
            ripeness: { type: Type.STRING },
            confidence: { type: Type.NUMBER },
          },
          required: [
            "type",
            "species",
            "description",
            "isFruitOrVeg",
            "ripeness",
            "confidence",
          ],
        },
      },
    });

    // Extrair o conteúdo corretamente
    const modelResponse = response?.response ?? response;
    const textOutput = modelResponse?.output_text || modelResponse?.candidates?.[0]?.content?.parts?.[0]?.text;
    console.log("Resposta bruta da API:", textOutput);
    // Tenta fazer parse se vier em JSON
    let data: any = {};
    try {
      data = typeof textOutput === "string" ? JSON.parse(textOutput) : textOutput;
    } catch {
      // fallback caso venha em formato texto plano
      data = { description: textOutput };
    }

    // Corrigir ortografia da primeira palavra, se existir
    if (data?.description) {
      data.description = fixFirstWord(data.description);
    }

    return NextResponse.json(data, { status: 200 });
  } catch (error: any) {
    console.error("Erro na análise:", error);
    return NextResponse.json(
      { error: "Erro ao processar a imagem." },
      { status: 500 }
    );
  }
}
