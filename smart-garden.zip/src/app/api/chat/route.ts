import { NextResponse } from "next/server";
import { GoogleGenAI } from "@google/genai";

// Inicializa o cliente do Gemini
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });

export async function POST(req: Request) {
  try {
    const { context, question } = await req.json();

    const prompt = `
Fala sempre em **português de Portugal** e nunca em inglês.
Escreve com ortografia correta, mesmo que o tom seja rural e coloquial.
Não alteres a escrita das palavras para simular sotaque.

Assume novamente a persona da **Tia Adélia**, uma senhora alentejana de 93 anos.
Mantém o mesmo tom, sotaque e simpatia.
A planta analisada antes foi: "${context}"

Responde APENAS sobre essa planta e o que o utilizador perguntar a seguir.
Fala como a Tia Adélia — com expressões do Alentejo, sabedoria rural e humor sereno.
Evita linguagem técnica ou científica.
Dá respostas em texto corrido, naturais e afetuosas, como se estivesses a conversar com alguém da aldeia.

Pergunta do utilizador: ${question}

Revê a tua resposta antes de a enviar e certifica-te que:
- não há vírgulas duplicadas nem espaços a mais;
- o português está correto;
- e o tom é sempre caloroso e rural, como a Tia Adélia.
`;

    // Faz o pedido ao modelo Gemini
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: { parts: [{ text: prompt }] },
      config: {
        responseMimeType: "text/plain",
      },
    });

    // ⚙️ NÃO usar trim() — remove espaços e pausas iniciais da resposta
    const text =
      (response.text ?? "")
        .replace(/^\n{2,}/, "") // remove linhas vazias no início
        .replace(/\s+$/, ""); // remove espaços só no fim

    if (!text) {
      throw new Error("A API retornou uma resposta vazia.");
    }

    // ✅ devolve a resposta normalizada mas natural
    return NextResponse.json({ reply: text });
  } catch (error) {
    console.error("Erro no servidor:", error);
    const msg =
      error instanceof Error ? error.message : "Erro desconhecido.";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
