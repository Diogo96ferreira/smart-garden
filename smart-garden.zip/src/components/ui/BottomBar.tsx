'use client';

import { useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { Home, ShoppingBag, Wrench, Building, HelpCircle } from 'lucide-react';
import clsx from 'clsx';

export default function BottomBar() {
  const router = useRouter();
  const pathname = usePathname();

  const items = [
    { id: 'home', icon: Home, href: '/dashboard', color: '#166534' },
    { id: 'garden', icon: ShoppingBag, href: '/garden', color: '#166534' },
    { id: 'calendar', icon: Wrench, href: '/calendar', color: '#166534' },
    { id: 'ai', icon: Building, href: '/ai', color: '#166534' },
    { id: 'settings', icon: HelpCircle, href: '/settings', color: '#166534' },
  ];

  const [active, setActive] = useState(
    items.find((i) => pathname.startsWith(i.href))?.id || 'home'
  );

  const handleClick = (id: string, href: string) => {
    setActive(id);
    router.push(href);
  };

  return (
    <div
      className={clsx(
        'fixed bottom-0 left-0 right-0 flex justify-center items-end z-50 transition-colors duration-500'
      )}
    >
      <ul className="relative flex justify-around items-end bg-[#f9f8fa] w-full max-w-md h-[60px] shadow-[0_-4px_10px_rgba(0,0,0,0.1)]">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.id;

          return (
            <li
              key={item.id}
              onClick={() => handleClick(item.id, item.href)}
              className={clsx(
                'flex justify-center items-center w-[60px] h-[60px] rounded-t-full relative cursor-pointer transition-all duration-300',
                isActive ? '-top-3' : 'top-0'
              )}
            >

              {/* Ícone */}
              <div
                className={clsx(
                  'flex justify-center items-center rounded-full w-[60px] h-[60px] transition-all duration-300',
                  isActive
                    ? 'text-white'
                    : 'text-gray-400 bg-[#f9f8fa]'
                )}
                style={{
                  backgroundColor: '#f9f8fa',
                  color: isActive ? item.color : '#a3a3a3',
                }}
              >
                <Icon className={clsx('w-6 h-6 transition-transform', isActive && 'scale-110')} />
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
