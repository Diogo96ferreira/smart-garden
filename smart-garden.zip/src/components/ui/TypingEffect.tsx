import { useEffect, useRef, useState } from "react";

function TypingText({ text }: { text: string }) {
  const [displayed, setDisplayed] = useState("");
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!text) return;

    let i = 0;
    setDisplayed("");
    const interval = setInterval(() => {
      setDisplayed((prev) => prev + text.charAt(i));
      i++;

      // auto-scroll
      if (containerRef.current) {
        containerRef.current.scrollTop = containerRef.current.scrollHeight;
      }

      if (i >= text.length) clearInterval(interval);
    }, 20); // velocidade em ms por letra

    return () => clearInterval(interval);
  }, [text]);

  return (
    <div
      ref={containerRef}
      className="whitespace-pre-wrap leading-relaxed font-serif border-r-2 border-green-700 pr-2"
    >
      {displayed}
    </div>
  );
}

export default TypingText;
